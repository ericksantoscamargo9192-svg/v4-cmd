package br.com.delanhol.comandas.domain

/** Uma linha do cupom, independente do tipo de impressora. */
data class LinhaImp(
    val texto: String,
    /** 0 = esquerda, 1 = centro */
    val alinhamento: Int = 0,
    val negrito: Boolean = false,
    /** 0 = normal, 1 = altura dupla, 2 = altura e largura duplas */
    val tamanho: Int = 0
)

data class Documento(val linhas: List<LinhaImp>)

class DocBuilder {
    private val l = mutableListOf<LinhaImp>()
    fun linha(texto: String = "", negrito: Boolean = false, tamanho: Int = 0, alin: Int = 0) = apply {
        l.add(LinhaImp(texto, alin, negrito, tamanho))
    }
    fun separador() = linha("-".repeat(LARGURA))
    fun montar() = Documento(l.toList())
}

/** Converte o documento em comandos ESC/POS (impressora Bluetooth comum). */
object EscPosRender {
    fun render(doc: Documento, acentos: Boolean): ByteArray {
        val e = EscPos(acentos)
        for (ln in doc.linhas) {
            e.alinhar(ln.alinhamento)
            e.negrito(ln.negrito)
            e.tamanho(when (ln.tamanho) { 1 -> 0x01; 2 -> 0x11; else -> 0x00 })
            e.linha(ln.texto)
        }
        e.alinhar(0).negrito(false).tamanho(0x00).avancar(4)
        return e.montar()
    }
}
