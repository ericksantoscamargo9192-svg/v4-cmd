package br.com.delanhol.comandas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import br.com.delanhol.comandas.data.ImpressoraBt
import br.com.delanhol.comandas.ui.AppRoot
import br.com.delanhol.comandas.ui.theme.DelAnholTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ImpressoraBt.iniciar(applicationContext)
        setContent { DelAnholTheme { AppRoot() } }
    }
}
