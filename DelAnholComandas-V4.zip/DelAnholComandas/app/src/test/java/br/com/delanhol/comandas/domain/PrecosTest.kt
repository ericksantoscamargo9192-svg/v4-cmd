package br.com.delanhol.comandas.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class PrecosTest {
    @Test fun tamanhosBase() {
        assertEquals(1800, Precos.total(Tamanho.P, emptyMap()))
        assertEquals(2100, Precos.total(Tamanho.M, emptyMap()))
        assertEquals(2500, Precos.total(Tamanho.G, emptyMap()))
    }
    @Test fun comAdicionais() {
        val adic = mapOf(Adicional.OVO_FRITO to 2, Adicional.BATATA_FRITA to 1)
        assertEquals(2500 + 400 + 500, Precos.total(Tamanho.G, adic))
    }
    @Test fun pfEMarmitaTemMesmoValor() {
        val pf = Pedido(1, TipoPrato.PF, Tamanho.M, "Frango", emptyMap(), Destino.Retirada)
        val mq = pf.copy(tipo = TipoPrato.MARMITA)
        assertEquals(pf.totalCentavos, mq.totalCentavos)
    }
    @Test fun formataReais() {
        assertEquals("R$ 18,00", Precos.formatar(1800))
        assertEquals("R$ 5,05", Precos.formatar(505))
    }
    @Test(expected = IllegalArgumentException::class) fun mesaInvalida() { Destino.Mesa(11) }
}
