package br.com.delanhol.comandas.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import br.com.delanhol.comandas.data.*
import br.com.delanhol.comandas.domain.*
import br.com.delanhol.comandas.service.CozinhaEstado
import br.com.delanhol.comandas.service.CozinhaService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Imprime em segundo plano e avisa o resultado na tela. */
internal fun imprimirComAviso(
    scope: CoroutineScope,
    snack: SnackbarHostState,
    doc: Documento,
    acentos: Boolean,
    uuid: String?,
    msgOk: String
) {
    scope.launch(Dispatchers.IO) {
        val ok = ImpressoraBt.imprimir(doc, acentos, uuid)
        snack.showSnackbar(if (ok) msgOk else (ImpressoraBt.estado.value.mensagem ?: "Falha ao imprimir"))
    }
}

@Composable
fun CozinhaApp() {
    val ctx = LocalContext.current
    val config = remember { ConfigRepository(ctx) }
    var aba by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }

    val permissoes = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()
    }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        // Depois que o Bluetooth for permitido, tenta voltar à última impressora.
        Thread { runCatching { ImpressoraBt.reconectarSalva() } }.start()
    }

    LaunchedEffect(Unit) {
        ImpressoraBt.iniciar(ctx)
        if (permissoes.isNotEmpty()) pedir.launch(permissoes)
        ContextCompat.startForegroundService(ctx, Intent(ctx, CozinhaService::class.java))
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = aba == 0, onClick = { aba = 0 },
                    icon = { Icon(Icons.Filled.Restaurant, null) }, label = { Text("Pedidos") }
                )
                NavigationBarItem(
                    selected = aba == 1, onClick = { aba = 1 },
                    icon = { Icon(Icons.Filled.BarChart, null) }, label = { Text("Resumo") }
                )
                NavigationBarItem(
                    selected = aba == 2, onClick = { aba = 2 },
                    icon = { Icon(Icons.Filled.Print, null) }, label = { Text("Impressora") }
                )
            }
        }
    ) { pad ->
        when (aba) {
            0 -> PedidosCozinha(config, snack, Modifier.padding(pad))
            1 -> ResumoCozinha(config, snack, Modifier.padding(pad))
            else -> ImpressoraTela(
                config, snack,
                pedirPermissoes = { if (permissoes.isNotEmpty()) pedir.launch(permissoes) },
                modifier = Modifier.padding(pad)
            )
        }
    }
}

@Composable
private fun ResumoCozinha(config: ConfigRepository, snack: SnackbarHostState, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    val todos by CozinhaEstado.pedidos.collectAsState()
    ResumoTela(
        pedidos = todos,
        onImprimir = { r ->
            imprimirComAviso(scope, snack, Cupons.resumoDoc(r), config.acentos(), null, "Resumo enviado à impressora")
        },
        modifier = modifier
    )
}

@Composable
private fun PedidosCozinha(config: ConfigRepository, snack: SnackbarHostState, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    val todos by CozinhaEstado.pedidos.collectAsState()
    val impressos by ImpressoraBt.impressos.collectAsState()
    val rodando by CozinhaEstado.rodando.collectAsState()
    val erro by CozinhaEstado.erro.collectAsState()
    val impressora by ImpressoraBt.estado.collectAsState()

    val hoje = LocalDate.now()
    val doDia = todos.filter { Resumo.diaDe(it) == hoje }
    val pendentes = doDia.filter { it.status == StatusPedido.EM_PREPARO }.sortedBy { it.numero }
    val feitos = doDia.filter { it.status != StatusPedido.EM_PREPARO }.sortedByDescending { it.numero }
    val ordem = pendentes + feitos

    fun mudar(p: Pedido, novo: StatusPedido) {
        scope.launch(Dispatchers.IO) { CozinhaEstado.servidor?.mudarStatus(p.uuid, novo) }
    }

    Column(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Secao("Cozinha") {
            Text(
                if (rodando) "Ativa — ${pendentes.size} em preparo" else "Iniciando…",
                fontWeight = FontWeight.Bold,
                color = if (rodando) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text("Endereço: ${ipLocal() ?: "sem Wi-Fi"} · porta ${Rede.PORTA}", style = MaterialTheme.typography.bodySmall)
            Text(
                if (impressora.conectada) "Impressora: ${impressora.nome ?: "conectada"}" else "Impressora desconectada",
                style = MaterialTheme.typography.bodySmall
            )
            erro?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }

        if (ordem.isEmpty()) {
            Text("Nenhum pedido hoje. Quando o balcão enviar, aparece aqui com aviso sonoro.")
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ordem, key = { it.uuid }) { p ->
                    CartaoPedido(
                        p = p,
                        impresso = p.uuid in impressos,
                        onFinalizar = { mudar(p, StatusPedido.PRONTO) },
                        onEntregue = { mudar(p, StatusPedido.ENTREGUE) },
                        onDesfazer = {
                            mudar(p, if (p.status == StatusPedido.ENTREGUE) StatusPedido.PRONTO else StatusPedido.EM_PREPARO)
                        },
                        onImprimir = {
                            imprimirComAviso(
                                scope, snack, Cupons.comandaDoc(p), config.acentos(), p.uuid,
                                "Comanda ${p.numero} enviada à impressora"
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CartaoPedido(
    p: Pedido,
    impresso: Boolean,
    onFinalizar: () -> Unit,
    onEntregue: () -> Unit,
    onDesfazer: () -> Unit,
    onImprimir: () -> Unit
) {
    val feito = p.status != StatusPedido.EM_PREPARO
    val rotuloStatus = when (p.status) {
        StatusPedido.EM_PREPARO -> "Em preparo"
        StatusPedido.PRONTO -> "Finalizado"
        StatusPedido.ENTREGUE -> "Entregue"
    }
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (feito) Color(0xFFE4DAC4) else Color.White)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            // Depois de finalizado, o texto fica opaco; os botões continuam normais.
            Column(Modifier.alpha(if (feito) 0.45f else 1f)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("#${p.numero} · ${p.destino.rotulo}", fontFamily = FonteTitulo, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(rotuloStatus, fontWeight = FontWeight.Bold)
                }
                Text("${p.tipo.rotulo} ${p.tamanho.rotulo} · ${p.prato}", fontWeight = FontWeight.Bold)
                if (p.adicionais.isNotEmpty()) {
                    Text("+ " + p.adicionais.entries.joinToString(", ") { "${it.value}x ${it.key.rotulo}" })
                }
                if (p.observacao.isNotBlank()) Text("OBS: ${p.observacao}", fontWeight = FontWeight.Bold)
                Text(Precos.formatar(p.totalCentavos))
            }
            if (impresso) Text("Impressa", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                when (p.status) {
                    StatusPedido.EM_PREPARO -> Button(
                        onClick = onFinalizar,
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("FINALIZAR", fontWeight = FontWeight.ExtraBold)
                    }
                    StatusPedido.PRONTO -> {
                        OutlinedButton(onClick = onEntregue, modifier = Modifier.weight(1f)) { Text("Marcar entregue") }
                        TextButton(onClick = onDesfazer) { Text("Desfazer") }
                    }
                    StatusPedido.ENTREGUE -> {
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = onDesfazer) { Text("Desfazer") }
                    }
                }
                OutlinedButton(onClick = onImprimir) {
                    Icon(Icons.Filled.Print, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Imprimir")
                }
            }
        }
    }
}
