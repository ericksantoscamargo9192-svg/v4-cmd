package br.com.delanhol.comandas.data

import br.com.delanhol.comandas.domain.*
import org.json.JSONObject

/** Converte pedidos de/para JSON. Cada mensagem da rede é um JSON em uma linha. */
object PedidoJson {
    fun destinoTexto(d: Destino): String = when (d) {
        is Destino.Mesa -> "MESA:${d.numero}"
        Destino.Retirada -> "RETIRADA"
        Destino.Entrega -> "ENTREGA"
    }

    fun destinoDe(s: String): Destino = when {
        s.startsWith("MESA:") -> Destino.Mesa(s.substringAfter(":").toInt())
        s == "RETIRADA" -> Destino.Retirada
        s == "ENTREGA" -> Destino.Entrega
        else -> throw IllegalArgumentException("Destino inválido: $s")
    }

    fun para(p: Pedido): JSONObject {
        val adic = JSONObject()
        p.adicionais.forEach { (a, q) -> adic.put(a.name, q) }
        return JSONObject()
            .put("id", p.uuid)
            .put("numero", p.numero)
            .put("tipo", p.tipo.name)
            .put("tamanho", p.tamanho.name)
            .put("prato", p.prato)
            .put("obs", p.observacao)
            .put("destino", destinoTexto(p.destino))
            .put("status", p.status.name)
            .put("criadoEm", p.criadoEmMillis)
            .put("adic", adic)
    }

    fun de(o: JSONObject): Pedido {
        val adic = mutableMapOf<Adicional, Int>()
        o.optJSONObject("adic")?.let { a ->
            a.keys().forEach { k -> adic[Adicional.valueOf(k)] = a.getInt(k) }
        }
        return Pedido(
            numero = o.optInt("numero", 0),
            tipo = TipoPrato.valueOf(o.getString("tipo")),
            tamanho = Tamanho.valueOf(o.getString("tamanho")),
            prato = o.getString("prato"),
            adicionais = adic,
            destino = destinoDe(o.getString("destino")),
            status = StatusPedido.valueOf(o.optString("status", StatusPedido.EM_PREPARO.name)),
            criadoEmMillis = o.optLong("criadoEm", System.currentTimeMillis()),
            observacao = o.optString("obs", ""),
            uuid = o.getString("id")
        )
    }
}
