package br.com.delanhol.comandas.domain

import java.io.ByteArrayOutputStream

/** Imagem 1 bit, 384 pontos de largura (papel de 58 mm). true = ponto preto. */
class Raster(val altura: Int, val pixels: BooleanArray) {
    init { require(pixels.size == altura * GatoProtocolo.LARGURA) { "Tamanho do raster inválido" } }
}

/**
 * Protocolo das "mini impressoras de gato" (GB01/GB02/GB03, MX05, etc.), por BLE.
 * Pacote: 51 78 CMD 00 LEN_LO LEN_HI DADOS CRC8(DADOS) FF   (CRC-8, polinômio 0x07).
 * O formato dos pacotes foi conferido com quadros publicados por projetos que estudaram esse protocolo.
 */
object GatoProtocolo {
    const val LARGURA = 384
    const val BYTES_POR_LINHA = LARGURA / 8

    private val TABELA = IntArray(256) { i ->
        var c = i
        repeat(8) { c = if (c and 0x80 != 0) ((c shl 1) xor 0x07) and 0xFF else (c shl 1) and 0xFF }
        c
    }

    fun crc8(dados: ByteArray): Int {
        var c = 0
        for (b in dados) c = TABELA[c xor (b.toInt() and 0xFF)]
        return c
    }

    fun pacote(cmd: Int, dados: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x51); out.write(0x78); out.write(cmd); out.write(0x00)
        out.write(dados.size and 0xFF); out.write((dados.size shr 8) and 0xFF)
        out.write(dados, 0, dados.size)
        out.write(crc8(dados)); out.write(0xFF)
        return out.toByteArray()
    }

    private val LATTICE_INICIO = intArrayOf(0xAA, 0x55, 0x17, 0x38, 0x44, 0x5F, 0x5F, 0x5F, 0x44, 0x38, 0x2C)
    private val LATTICE_FIM = intArrayOf(0xAA, 0x55, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17)

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
    private fun bytes(v: IntArray) = ByteArray(v.size) { v[it].toByte() }

    /** 0 = leve, 1 = normal, 2 = escura */
    fun energia(intensidade: Int): Int = when (intensidade) { 0 -> 0x3000; 2 -> 0xFFFF; else -> 0x5DC0 }

    /** Uma linha da imagem: o ponto mais à esquerda fica no bit menos significativo do byte. */
    fun linha(r: Raster, y: Int): ByteArray {
        val out = ByteArray(BYTES_POR_LINHA)
        for (x in 0 until LARGURA) {
            if (r.pixels[y * LARGURA + x]) {
                out[x / 8] = (out[x / 8].toInt() or (1 shl (x % 8))).toByte()
            }
        }
        return out
    }

    /** Sequência completa de um trabalho de impressão. */
    fun trabalho(r: Raster, intensidade: Int, avancoFinal: Int = 96): ByteArray {
        val out = ByteArrayOutputStream()
        fun add(b: ByteArray) = out.write(b, 0, b.size)
        add(pacote(0xA3, bytes(0x00)))                                   // estado do aparelho
        add(pacote(0xA4, bytes(0x32)))                                   // qualidade
        add(pacote(0xA6, bytes(LATTICE_INICIO)))                         // início
        val e = energia(intensidade)
        add(pacote(0xAF, bytes(e and 0xFF, (e shr 8) and 0xFF)))         // energia (escuridão)
        add(pacote(0xBE, bytes(0x01)))                                   // modo texto: mais contraste
        for (y in 0 until r.altura) add(pacote(0xA2, linha(r, y)))       // uma linha por pacote
        add(pacote(0xA1, bytes(avancoFinal and 0xFF, (avancoFinal shr 8) and 0xFF))) // avança o papel
        add(pacote(0xA6, bytes(LATTICE_FIM)))                            // fim
        add(pacote(0xA3, bytes(0x00)))
        return out.toByteArray()
    }
}
