package br.com.delanhol.comandas.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TableRestaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.delanhol.comandas.data.PratoDia
import br.com.delanhol.comandas.domain.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BalcaoScreen(
    pratos: List<PratoDia>,
    onEnviar: (RascunhoPedido) -> Unit,
    modifier: Modifier = Modifier
) {
    var r by remember { mutableStateOf(RascunhoPedido()) }
    var erro by remember { mutableStateOf<String?>(null) }
    val nomes = pratos.map { it.nome }.filter { it.isNotBlank() }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Secao("Tipo") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TipoPrato.entries.forEach { t ->
                    FilterChip(
                        selected = r.tipo == t,
                        onClick = { r = r.copy(tipo = t) },
                        label = { Text(t.rotulo) },
                        leadingIcon = {
                            Icon(
                                if (t == TipoPrato.PF) Icons.Filled.Restaurant else Icons.Filled.ShoppingBag,
                                contentDescription = null
                            )
                        }
                    )
                }
            }
        }

        Secao("Tamanho") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tamanho.entries.forEach { t ->
                    FilterChip(
                        selected = r.tamanho == t,
                        onClick = { r = r.copy(tamanho = t) },
                        label = { Text("${t.rotulo} · ${Precos.formatar(t.precoCentavos)}") }
                    )
                }
            }
        }

        Secao("Prato do dia") {
            if (nomes.isEmpty()) {
                Text("Cadastre os pratos do dia na aba Cardápio.")
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    nomes.forEach { n ->
                        FilterChip(
                            selected = r.prato == n,
                            onClick = { r = r.copy(prato = n) },
                            label = { Text(n) }
                        )
                    }
                }
            }
        }

        Secao("Adicionais") {
            Adicional.entries.forEach { a ->
                val qtd = r.adicionais[a] ?: 0
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.rotulo, fontWeight = FontWeight.Bold)
                        Text(Precos.formatar(a.precoCentavos), style = MaterialTheme.typography.bodySmall)
                    }
                    FilledTonalIconButton(onClick = { r = r.comAdicional(a, -1) }) {
                        Icon(Icons.Filled.Remove, contentDescription = "Menos ${a.rotulo}")
                    }
                    Text("$qtd", Modifier.padding(horizontal = 12.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    FilledTonalIconButton(onClick = { r = r.comAdicional(a, 1) }) {
                        Icon(Icons.Filled.Add, contentDescription = "Mais ${a.rotulo}")
                    }
                }
            }
        }

        Secao("Destino") {
            val destinos: List<Destino> =
                (1..10).map { Destino.Mesa(it) } + listOf(Destino.Retirada, Destino.Entrega)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                destinos.forEach { d ->
                    FilterChip(
                        selected = r.destino == d,
                        onClick = { r = r.copy(destino = d) },
                        label = { Text(d.rotulo) },
                        leadingIcon = {
                            Icon(
                                when (d) {
                                    is Destino.Mesa -> Icons.Filled.TableRestaurant
                                    Destino.Retirada -> Icons.Filled.ShoppingBag
                                    Destino.Entrega -> Icons.Filled.DeliveryDining
                                },
                                contentDescription = null
                            )
                        }
                    )
                }
            }
        }

        Secao("Observação") {
            OutlinedTextField(
                value = r.observacao,
                onValueChange = { if (it.length <= RascunhoPedido.MAX_OBS) r = r.copy(observacao = it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Ex.: sem cebola, arroz separado") },
                supportingText = { Text("${r.observacao.length}/${RascunhoPedido.MAX_OBS}") },
                minLines = 2
            )
        }

        Secao("Total") {
            Text(
                Precos.formatar(r.totalCentavos),
                fontFamily = FonteTitulo,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        erro?.let { Text(it, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }

        Button(
            onClick = {
                val e = r.erro()
                if (e != null) {
                    erro = e
                } else {
                    onEnviar(r)
                    r = RascunhoPedido()
                    erro = null
                }
            },
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) {
            Icon(Icons.Filled.Send, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("ENVIAR COMANDA", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(8.dp))
    }
}
