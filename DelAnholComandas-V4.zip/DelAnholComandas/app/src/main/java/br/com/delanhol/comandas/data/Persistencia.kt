package br.com.delanhol.comandas.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import br.com.delanhol.comandas.domain.Pedido
import br.com.delanhol.comandas.domain.Resumo
import br.com.delanhol.comandas.domain.StatusPedido
import org.json.JSONArray
import org.json.JSONObject

/**
 * Banco SQLite da cozinha (grátis, local). A numeração reinicia a cada dia:
 * o primeiro pedido do dia é o nº 1.
 */
class PedidoDb(context: Context) : SQLiteOpenHelper(context, "cozinha_v2.db", null, 1), PedidoStore {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE pedidos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "uuid TEXT NOT NULL UNIQUE, " +
                "dia TEXT NOT NULL, " +
                "numero INTEGER NOT NULL, " +
                "json TEXT NOT NULL, " +
                "criado INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, antiga: Int, nova: Int) {}

    @Synchronized
    override fun receber(p: Pedido): Recebido {
        require(p.uuid.isNotBlank()) { "Pedido sem identificador" }
        val db = writableDatabase
        db.rawQuery("SELECT json FROM pedidos WHERE uuid = ?", arrayOf(p.uuid)).use { c ->
            if (c.moveToFirst()) return Recebido(PedidoJson.de(JSONObject(c.getString(0))), false)
        }
        val agora = System.currentTimeMillis()
        val dia = Resumo.diaDe(p.copy(criadoEmMillis = agora)).toString()
        var numero = 1
        db.rawQuery(
            "SELECT COALESCE(MAX(numero), 0) + 1 FROM pedidos WHERE dia = ?", arrayOf(dia)
        ).use { c -> if (c.moveToFirst()) numero = c.getInt(0) }
        val salvo = p.copy(numero = numero, criadoEmMillis = agora)
        val v = ContentValues().apply {
            put("uuid", salvo.uuid)
            put("dia", dia)
            put("numero", numero)
            put("json", PedidoJson.para(salvo).toString())
            put("criado", agora)
        }
        db.insertOrThrow("pedidos", null, v)
        return Recebido(salvo, true)
    }

    @Synchronized
    override fun atualizarStatus(uuid: String, status: StatusPedido): Pedido? {
        val db = writableDatabase
        var atual: Pedido? = null
        db.rawQuery("SELECT json FROM pedidos WHERE uuid = ?", arrayOf(uuid)).use { c ->
            if (c.moveToFirst()) atual = PedidoJson.de(JSONObject(c.getString(0)))
        }
        val novo = atual?.copy(status = status) ?: return null
        db.execSQL(
            "UPDATE pedidos SET json = ? WHERE uuid = ?",
            arrayOf<Any>(PedidoJson.para(novo).toString(), uuid)
        )
        return novo
    }

    @Synchronized
    override fun listar(): List<Pedido> {
        val lista = mutableListOf<Pedido>()
        readableDatabase.rawQuery("SELECT json FROM pedidos ORDER BY id", null).use { c ->
            while (c.moveToNext()) lista.add(PedidoJson.de(JSONObject(c.getString(0))))
        }
        return lista
    }
}

/** Fila de saída do balcão guardada no aparelho: sobrevive se o app for fechado. */
class FilaPrefs(context: Context) : FilaSaida {
    private val prefs = context.getSharedPreferences("fila_saida", Context.MODE_PRIVATE)

    private fun ler(): MutableList<JSONObject> {
        val arr = JSONArray(prefs.getString("itens", "[]"))
        return MutableList(arr.length()) { arr.getJSONObject(it) }
    }

    private fun gravar(itens: List<JSONObject>) {
        val arr = JSONArray()
        itens.forEach { arr.put(it) }
        prefs.edit().putString("itens", arr.toString()).apply()
    }

    @Synchronized override fun adicionar(msg: JSONObject) {
        val itens = ler()
        if (itens.none { it.getString("id") == msg.getString("id") }) {
            itens.add(msg)
            gravar(itens)
        }
    }

    @Synchronized override fun todos(): List<JSONObject> = ler()

    @Synchronized override fun remover(id: String) {
        gravar(ler().filter { it.getString("id") != id })
    }
}
