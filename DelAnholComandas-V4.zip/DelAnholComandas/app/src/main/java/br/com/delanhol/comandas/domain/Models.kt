package br.com.delanhol.comandas.domain

enum class TipoPrato(val rotulo: String) { PF("PF"), MARMITA("Marmita") }

enum class Tamanho(val rotulo: String, val precoCentavos: Int) {
    P("P", 1800), M("M", 2100), G("G", 2500)
}

enum class Adicional(val rotulo: String, val precoCentavos: Int) {
    OVO_FRITO("Ovo frito", 200),
    BATATA_FRITA("Batata frita", 500),
    ADICIONAL("Adicional", 500)
}

sealed class Destino {
    data class Mesa(val numero: Int) : Destino() {
        init { require(numero in 1..10) { "Mesa deve ser de 1 a 10" } }
    }
    object Retirada : Destino()
    object Entrega : Destino()

    val rotulo: String
        get() = when (this) {
            is Mesa -> "Mesa $numero"
            Retirada -> "Retirada"
            Entrega -> "Entrega"
        }
}

enum class StatusPedido(val rotulo: String) {
    EM_PREPARO("Em preparo"), PRONTO("Pronto"), ENTREGUE("Entregue")
}

/** Item de um pedido. Valores em centavos para evitar erro de arredondamento. */
data class Pedido(
    val numero: Int,
    val tipo: TipoPrato,
    val tamanho: Tamanho,
    val prato: String,
    val adicionais: Map<Adicional, Int>,
    val destino: Destino,
    val status: StatusPedido = StatusPedido.EM_PREPARO,
    val criadoEmMillis: Long = System.currentTimeMillis(),
    val observacao: String = "",
    /** Identificador criado no balcão; evita pedido duplicado se o envio for repetido. */
    val uuid: String = ""
) {
    val totalCentavos: Int get() = Precos.total(tamanho, adicionais)
}
