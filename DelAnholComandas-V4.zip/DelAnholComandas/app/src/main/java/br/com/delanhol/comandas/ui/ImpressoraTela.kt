package br.com.delanhol.comandas.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.com.delanhol.comandas.data.*
import br.com.delanhol.comandas.domain.Cupons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImpressoraTela(
    config: ConfigRepository,
    snack: SnackbarHostState,
    pedirPermissoes: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val est by ImpressoraBt.estado.collectAsState()
    var auto by remember { mutableStateOf(config.autoImprimir()) }
    var acentos by remember { mutableStateOf(config.acentos()) }
    var som by remember { mutableStateOf(config.somAlerta()) }
    var salva by remember { mutableStateOf(config.impressoraNome()) }
    var tipoSalvo by remember { mutableStateOf(config.impressoraTipo()) }
    var intensidade by remember { mutableIntStateOf(config.intensidade()) }
    var escolhendo by remember { mutableStateOf<List<DispositivoBt>?>(null) }
    var dialogoMini by remember { mutableStateOf(false) }
    var buscando by remember { mutableStateOf(false) }
    var pararBusca by remember { mutableStateOf<(() -> Unit)?>(null) }
    val achados = remember { mutableStateListOf<DispositivoBt>() }
    val versao = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    fun conectarEAvisar(d: DispositivoBt, tipo: TipoImpressora) {
        config.definirImpressora(d.endereco, d.nome, tipo)
        salva = d.nome
        tipoSalvo = tipo
        scope.launch(Dispatchers.IO) {
            val ok = ImpressoraBt.conectar(d.endereco, d.nome, tipo)
            snack.showSnackbar(
                if (ok) "Conectada a ${d.nome}"
                else (ImpressoraBt.estado.value.mensagem ?: "Falha ao conectar")
            )
        }
    }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Secao("Impressora") {
            val qual = if (tipoSalvo == TipoImpressora.GATO) "mini impressora" else "Bluetooth comum"
            when {
                est.conectada -> Text(
                    "Conectada: ${est.nome ?: ""} ($qual)",
                    fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32)
                )
                est.ocupada -> Text("Conectando…", fontWeight = FontWeight.Bold)
                else -> Text(
                    if (salva != null) "Desconectada (última: $salva, $qual)" else "Nenhuma impressora escolhida",
                    fontWeight = FontWeight.Bold
                )
            }
            est.mensagem?.let { if (!est.ocupada) Text(it, color = MaterialTheme.colorScheme.error) }

            Button(
                onClick = {
                    if (!ImpressoraBt.temPermissao()) {
                        pedirPermissoes()
                        scope.launch { snack.showSnackbar("Permita o Bluetooth e toque de novo") }
                    } else {
                        escolhendo = ImpressoraBt.pareadas()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("ESCOLHER IMPRESSORA (PAREADA)", fontWeight = FontWeight.ExtraBold) }

            Button(
                onClick = {
                    if (!ImpressoraBt.temPermissao() || !ImpressoraBt.temPermissaoBusca()) {
                        pedirPermissoes()
                        scope.launch { snack.showSnackbar("Permita \"Dispositivos por perto\" e toque de novo") }
                    } else {
                        achados.clear()
                        dialogoMini = true
                        buscando = true
                        pararBusca = ImpressoraBt.buscarGatos(
                            8000,
                            { d -> if (achados.none { it.endereco == d.endereco }) achados.add(d) },
                            { buscando = false }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("PROCURAR MINI IMPRESSORA", fontWeight = FontWeight.ExtraBold) }

            if (est.conectada) {
                OutlinedButton(
                    onClick = { scope.launch(Dispatchers.IO) { ImpressoraBt.desconectar() } },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Desconectar") }
            } else if (salva != null) {
                OutlinedButton(
                    onClick = {
                        config.impressoraEndereco()?.let { end ->
                            scope.launch(Dispatchers.IO) { ImpressoraBt.conectar(end, salva, config.impressoraTipo()) }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Conectar") }
            }

            OutlinedButton(
                onClick = {
                    imprimirComAviso(
                        scope, snack,
                        Cupons.testeDoc(config.acentos(), tipoSalvo == TipoImpressora.GATO),
                        config.acentos(), null, "Teste enviado à impressora"
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Print, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Imprimir teste")
            }
        }

        Secao("Opções") {
            LinhaSwitch(
                "Imprimir ao chegar pedido",
                "A comanda sai sozinha assim que o balcão envia (impressora já escolhida).",
                auto
            ) { auto = it; config.definirAutoImprimir(it) }
            if (tipoSalvo == TipoImpressora.CLASSICA) {
                LinhaSwitch(
                    "Imprimir com acentos",
                    "Ligue só se o teste sair com acentos corretos. Desligado, sai sem acento.",
                    acentos
                ) { acentos = it; config.definirAcentos(it) }
            } else {
                Text("Intensidade da mini impressora", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Leve", "Normal", "Escura").forEachIndexed { i, rot ->
                        FilterChip(
                            selected = intensidade == i,
                            onClick = { intensidade = i; config.definirIntensidade(i) },
                            label = { Text(rot) }
                        )
                    }
                }
            }
            LinhaSwitch(
                "Som ao chegar pedido",
                "Toca no volume de alarme, mesmo com o celular no silencioso.",
                som
            ) { som = it; config.definirSomAlerta(it) }
        }
        Text("Versão do app: $versao", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
    }

    escolhendo?.let { lista ->
        AlertDialog(
            onDismissRequest = { escolhendo = null },
            title = { Text("Impressoras pareadas") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lista.isEmpty()) {
                        Text("Nenhum aparelho pareado. Ligue a impressora, pareie em Bluetooth e volte aqui. Para mini impressora, use o botão PROCURAR MINI IMPRESSORA.")
                        TextButton(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }) { Text("Abrir Bluetooth") }
                    } else {
                        lista.forEach { d ->
                            OutlinedButton(
                                onClick = { escolhendo = null; conectarEAvisar(d, TipoImpressora.CLASSICA) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(d.nome) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { escolhendo = null }) { Text("Fechar") } }
        )
    }

    if (dialogoMini) {
        AlertDialog(
            onDismissRequest = { pararBusca?.invoke(); dialogoMini = false },
            title = { Text(if (buscando) "Procurando…" else "Mini impressoras") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Ligue a mini impressora e deixe perto do celular. Feche outros apps que a usam (ela só aceita uma conexão).")
                    if (achados.isEmpty() && !buscando) Text("Nada encontrado. Toque em Fechar e tente de novo.")
                    achados.forEach { d ->
                        OutlinedButton(
                            onClick = {
                                pararBusca?.invoke()
                                dialogoMini = false
                                conectarEAvisar(d, TipoImpressora.GATO)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(d.nome) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pararBusca?.invoke(); dialogoMini = false }) { Text("Fechar") }
            }
        )
    }
}

@Composable
private fun LinhaSwitch(rotulo: String, detalhe: String, marcado: Boolean, aoMudar: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(rotulo, fontWeight = FontWeight.Bold)
            Text(detalhe, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = marcado, onCheckedChange = aoMudar)
    }
}
