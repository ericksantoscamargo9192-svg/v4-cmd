package br.com.delanhol.comandas.data

import android.content.Context

data class PratoDia(val nome: String = "", val categoria: String = "")

/** Guarda os três pratos do dia no aparelho até alguém alterar. */
class CardapioRepository(context: Context) {
    private val prefs = context.getSharedPreferences("cardapio", Context.MODE_PRIVATE)

    fun carregar(): List<PratoDia> = List(3) { i ->
        PratoDia(
            nome = prefs.getString("nome$i", "") ?: "",
            categoria = prefs.getString("cat$i", "") ?: ""
        )
    }

    fun salvar(pratos: List<PratoDia>) {
        val ed = prefs.edit()
        pratos.take(3).forEachIndexed { i, p ->
            ed.putString("nome$i", p.nome.trim())
            ed.putString("cat$i", p.categoria.trim())
        }
        ed.apply()
    }
}

enum class Modo { BALCAO, COZINHA }

class ConfigRepository(context: Context) {
    private val prefs = context.getSharedPreferences("config", Context.MODE_PRIVATE)

    fun modo(): Modo? = prefs.getString("modo", null)?.let { runCatching { Modo.valueOf(it) }.getOrNull() }

    fun definirModo(m: Modo?) {
        if (m == null) prefs.edit().remove("modo").apply()
        else prefs.edit().putString("modo", m.name).apply()
    }

    /** IP digitado à mão; se vazio, o balcão usa a descoberta automática. */
    fun ipCozinha(): String? = prefs.getString("ip_cozinha", null)?.ifBlank { null }

    fun definirIpCozinha(ip: String?) {
        if (ip.isNullOrBlank()) prefs.edit().remove("ip_cozinha").apply()
        else prefs.edit().putString("ip_cozinha", ip.trim()).apply()
    }

    // --- Cozinha: impressora e alertas ---
    fun autoImprimir(): Boolean = prefs.getBoolean("auto_imprimir", true)
    fun definirAutoImprimir(v: Boolean) { prefs.edit().putBoolean("auto_imprimir", v).apply() }

    /** false = imprime sem acentos (mais seguro); true = usa a tabela PC860. */
    fun acentos(): Boolean = prefs.getBoolean("acentos", false)
    fun definirAcentos(v: Boolean) { prefs.edit().putBoolean("acentos", v).apply() }

    fun somAlerta(): Boolean = prefs.getBoolean("som_alerta", true)
    fun definirSomAlerta(v: Boolean) { prefs.edit().putBoolean("som_alerta", v).apply() }

    fun impressoraEndereco(): String? = prefs.getString("impressora_end", null)
    fun impressoraNome(): String? = prefs.getString("impressora_nome", null)
    fun impressoraTipo(): TipoImpressora =
        prefs.getString("impressora_tipo", null)?.let { runCatching { TipoImpressora.valueOf(it) }.getOrNull() }
            ?: TipoImpressora.CLASSICA

    fun definirImpressora(endereco: String?, nome: String?, tipo: TipoImpressora = TipoImpressora.CLASSICA) {
        prefs.edit().putString("impressora_end", endereco).putString("impressora_nome", nome)
            .putString("impressora_tipo", tipo.name).apply()
    }

    /** Escuridão da mini impressora: 0 leve, 1 normal, 2 escura. */
    fun intensidade(): Int = prefs.getInt("intensidade", 1).coerceIn(0, 2)
    fun definirIntensidade(v: Int) { prefs.edit().putInt("intensidade", v).apply() }
}
