package br.com.delanhol.comandas.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class LinhaDestino(val rotulo: String, val comandas: Int, val totalCentavos: Int)

data class ResumoDia(
    val dia: LocalDate,
    val totalCentavos: Int,
    val comandas: Int,
    val pf: Int,
    val marmitas: Int,
    val tamanhos: Map<Tamanho, Int>,
    val adicionais: Map<Adicional, Int>,
    val destinos: List<LinhaDestino>
)

/** Fechamento do dia: tudo calculado a partir dos pedidos, sem estado próprio. */
object Resumo {
    fun diaDe(p: Pedido, zona: ZoneId = ZoneId.systemDefault()): LocalDate =
        Instant.ofEpochMilli(p.criadoEmMillis).atZone(zona).toLocalDate()

    fun calcular(
        pedidos: Collection<Pedido>,
        dia: LocalDate,
        zona: ZoneId = ZoneId.systemDefault()
    ): ResumoDia {
        val doDia = pedidos.filter { diaDe(it, zona) == dia }
        val tamanhos = Tamanho.entries.associateWith { t -> doDia.count { it.tamanho == t } }
        val adic = Adicional.entries.associateWith { a -> doDia.sumOf { it.adicionais[a] ?: 0 } }
        val ordem: List<Destino> =
            (1..10).map { Destino.Mesa(it) } + listOf(Destino.Retirada, Destino.Entrega)
        val destinos = ordem.mapNotNull { d ->
            val grupo = doDia.filter { it.destino == d }
            if (grupo.isEmpty()) null
            else LinhaDestino(d.rotulo, grupo.size, grupo.sumOf { it.totalCentavos })
        }
        return ResumoDia(
            dia = dia,
            totalCentavos = doDia.sumOf { it.totalCentavos },
            comandas = doDia.size,
            pf = doDia.count { it.tipo == TipoPrato.PF },
            marmitas = doDia.count { it.tipo == TipoPrato.MARMITA },
            tamanhos = tamanhos,
            adicionais = adic,
            destinos = destinos
        )
    }
}
