package br.com.delanhol.comandas.domain

import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.nio.charset.Charset
import java.time.ZoneId

class CupomTest {
    private val pedido = Pedido(
        numero = 5, tipo = TipoPrato.MARMITA, tamanho = Tamanho.G, prato = "Frango grelhado",
        adicionais = mapOf(Adicional.OVO_FRITO to 2), destino = Destino.Mesa(3),
        observacao = "sem cebola", uuid = "u1"
    )

    private fun texto(b: ByteArray) = String(b, Charsets.ISO_8859_1)

    @Test fun comandaTemOsDadosPrincipais() {
        val t = texto(Cupons.comanda(pedido, acentos = false, zona = ZoneId.of("UTC")))
        listOf("COMANDA 5", "MESA 3", "MARMITA G", "Frango grelhado", "+ 2x Ovo frito", "sem cebola", "R\$ 29,00")
            .forEach { assertTrue("faltou: $it", t.contains(it)) }
    }

    @Test fun quebraLinhasLongas() {
        val l = Texto.quebrar("a".repeat(70))
        assertEquals(listOf(32, 32, 6), l.map { it.length })
        val frase = Texto.quebrar("sem cebola arroz separado feijao a parte e muito mais coisa para testar a quebra")
        assertTrue(frase.all { it.length <= LARGURA })
    }

    @Test fun duasColunasTemLarguraCerta() {
        assertEquals(LARGURA, Texto.duasColunas("TOTAL", "R\$ 29,00").length)
    }

    @Test fun semAcentosRemoveAcentos() {
        assertEquals("acao e coracao", Texto.semAcentos("ação é coração").replace("é", "e"))
        assertArrayEquals("acao".toByteArray(), Texto.paraBytes("ação", acentos = false))
    }

    @Test fun acentosUsamPc860() {
        val b = Texto.paraBytes("ação", acentos = true)
        assertEquals(listOf(0x61, 0x87, 0x84, 0x6F), b.map { it.toInt() and 0xFF })
    }

    @Test fun tabelaPc860BateComOJava() {
        assumeTrue(Charset.isSupported("IBM860"))
        val cs = Charset.forName("IBM860")
        Texto.CP860.forEach { (c, b) ->
            assertEquals(c.toString(), String(byteArrayOf(b.toByte()), cs))
        }
    }
}
