package br.com.delanhol.comandas.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class ResumoTest {
    private val zona = ZoneId.of("UTC")
    private val dia = LocalDate.of(2026, 10, 31)

    private fun em(d: LocalDate) = d.atTime(12, 0).atZone(zona).toInstant().toEpochMilli()

    private fun p(
        tipo: TipoPrato, tam: Tamanho, destino: Destino,
        adic: Map<Adicional, Int> = emptyMap(), d: LocalDate = dia
    ) = Pedido(
        numero = 1, tipo = tipo, tamanho = tam, prato = "x", adicionais = adic,
        destino = destino, criadoEmMillis = em(d), uuid = "u${System.nanoTime()}"
    )

    @Test fun somaTudoDoDia() {
        val lista = listOf(
            p(TipoPrato.PF, Tamanho.M, Destino.Mesa(1)),
            p(TipoPrato.MARMITA, Tamanho.G, Destino.Retirada, mapOf(Adicional.OVO_FRITO to 2)),
            p(TipoPrato.PF, Tamanho.P, Destino.Mesa(1), mapOf(Adicional.BATATA_FRITA to 1)),
            p(TipoPrato.PF, Tamanho.G, Destino.Entrega, d = dia.minusDays(1))
        )
        val r = Resumo.calcular(lista, dia, zona)
        assertEquals(2100 + 2900 + 2300, r.totalCentavos)
        assertEquals(3, r.comandas)
        assertEquals(2, r.pf)
        assertEquals(1, r.marmitas)
        assertEquals(1, r.tamanhos[Tamanho.P]); assertEquals(1, r.tamanhos[Tamanho.M]); assertEquals(1, r.tamanhos[Tamanho.G])
        assertEquals(2, r.adicionais[Adicional.OVO_FRITO])
        assertEquals(1, r.adicionais[Adicional.BATATA_FRITA])
        assertEquals(listOf("Mesa 1", "Retirada"), r.destinos.map { it.rotulo })
        assertEquals(2, r.destinos[0].comandas)
        assertEquals(4400, r.destinos[0].totalCentavos)
    }

    @Test fun diaSemVendas() {
        val r = Resumo.calcular(emptyList(), dia, zona)
        assertEquals(0, r.totalCentavos)
        assertTrue(r.destinos.isEmpty())
    }
}
