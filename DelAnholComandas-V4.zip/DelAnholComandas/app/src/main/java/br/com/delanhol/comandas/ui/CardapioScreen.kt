package br.com.delanhol.comandas.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.delanhol.comandas.data.PratoDia

@Composable
fun CardapioScreen(
    pratos: List<PratoDia>,
    onSalvar: (List<PratoDia>) -> Unit,
    modifier: Modifier = Modifier
) {
    val editando = remember { pratos.toMutableStateList() }
    var salvo by remember { mutableStateOf(false) }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        editando.forEachIndexed { i, p ->
            Secao("Prato ${i + 1}") {
                OutlinedTextField(
                    value = p.nome,
                    onValueChange = { editando[i] = p.copy(nome = it); salvo = false },
                    label = { Text("Nome do prato") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = p.categoria,
                    onValueChange = { editando[i] = p.copy(categoria = it); salvo = false },
                    label = { Text("Categoria (ex.: Carne, Frango)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Button(
            onClick = { onSalvar(editando.toList()); salvo = true },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("SALVAR CARDÁPIO") }
        if (salvo) Text("Cardápio salvo. Fica assim até você alterar.")
    }
}
