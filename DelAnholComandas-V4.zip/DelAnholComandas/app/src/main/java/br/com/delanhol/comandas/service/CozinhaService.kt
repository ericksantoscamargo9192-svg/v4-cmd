package br.com.delanhol.comandas.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.wifi.WifiManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import br.com.delanhol.comandas.MainActivity
import br.com.delanhol.comandas.data.*
import br.com.delanhol.comandas.domain.Cupons
import br.com.delanhol.comandas.domain.Pedido
import kotlinx.coroutines.flow.MutableStateFlow

/** Estado visível pela tela da cozinha. */
object CozinhaEstado {
    val pedidos = MutableStateFlow<List<Pedido>>(emptyList())
    val rodando = MutableStateFlow(false)
    val erro = MutableStateFlow<String?>(null)
    @Volatile var servidor: ServidorCozinha? = null
}

/** Mantém o servidor da cozinha ligado, avisa e imprime quando chega pedido. */
class CozinhaService : Service() {
    private var servidor: ServidorCozinha? = null
    private var anuncio: AnuncioCozinha? = null
    private var db: PedidoDb? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var toque: Ringtone? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanais()
        ServiceCompat.startForeground(
            this, ID_FIXA, notificacaoFixa(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        ImpressoraBt.iniciar(applicationContext)
        if (servidor == null) iniciarServidor()
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun iniciarServidor() {
        val banco = PedidoDb(applicationContext).also { db = it }
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "delanhol:servidor")
            .also { it.acquire() }
        Thread({
            try {
                CozinhaEstado.pedidos.value = banco.listar()
                val s = ServidorCozinha(
                    store = banco,
                    porta = Rede.PORTA,
                    aoMudar = { CozinhaEstado.pedidos.value = banco.listar() },
                    aoNovo = { aoNovoPedido(it) }
                )
                val porta = s.iniciar()
                servidor = s
                CozinhaEstado.servidor = s
                anuncio = AnuncioCozinha(applicationContext).also { it.iniciar(porta) }
                CozinhaEstado.erro.value = null
                CozinhaEstado.rodando.value = true
            } catch (e: Exception) {
                CozinhaEstado.erro.value = "Não foi possível abrir a porta ${Rede.PORTA}: ${e.message}"
                CozinhaEstado.rodando.value = false
            }
            // Reconecta sozinho na última impressora usada (se já houver permissão).
            runCatching { ImpressoraBt.reconectarSalva() }
        }, "cozinha-iniciar").start()
    }

    /** Chamado quando chega um pedido novo: imprime (se automático) e avisa com som. */
    private fun aoNovoPedido(p: Pedido) {
        val cfg = ConfigRepository(applicationContext)
        if (cfg.autoImprimir() && cfg.impressoraEndereco() != null) {
            Thread({
                ImpressoraBt.imprimir(Cupons.comandaDoc(p), cfg.acentos(), p.uuid)
            }, "cozinha-imprimir").start()
        }
        alertar(p, cfg.somAlerta())
    }

    private fun alertar(p: Pedido, comSom: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CANAL_PEDIDOS)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Novo pedido #${p.numero} - ${p.destino.rotulo}")
            .setContentText("${p.tipo.rotulo} ${p.tamanho.rotulo} - ${p.prato}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(abrir)
            .build()
        nm.notify(p.uuid.hashCode(), n)

        if (comSom) {
            // Toca pelo volume de ALARME: soa mesmo com o celular no silencioso.
            runCatching {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val r = RingtoneManager.getRingtone(applicationContext, uri) ?: return
                r.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                toque?.stop()
                toque = r
                r.play()
            }
        }
    }

    override fun onDestroy() {
        servidor?.parar(); servidor = null
        CozinhaEstado.servidor = null
        anuncio?.parar(); anuncio = null
        wifiLock?.let { if (it.isHeld) it.release() }
        db?.close(); db = null
        CozinhaEstado.rodando.value = false
        super.onDestroy()
    }

    private fun criarCanais() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CANAL_FIXO, "Cozinha ativa", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CANAL_PEDIDOS, "Novos pedidos", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                setSound(null, null) // o som é tocado pelo serviço, no volume de alarme
            }
        )
    }

    private fun notificacaoFixa(): Notification =
        NotificationCompat.Builder(this, CANAL_FIXO)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Del Anhol - cozinha ativa")
            .setContentText("Recebendo pedidos do balcão")
            .setOngoing(true)
            .build()

    companion object {
        private const val CANAL_FIXO = "cozinha"
        private const val CANAL_PEDIDOS = "pedidos_novos"
        private const val ID_FIXA = 1
    }
}
