package br.com.delanhol.comandas.data

import br.com.delanhol.comandas.domain.Pedido
import br.com.delanhol.comandas.domain.StatusPedido
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object Rede { const val PORTA = 8765 }

data class Recebido(val pedido: Pedido, val novo: Boolean)

/** Guarda os pedidos da cozinha. Receber é idempotente: o mesmo uuid devolve o mesmo pedido. */
interface PedidoStore {
    fun receber(p: Pedido): Recebido
    fun listar(): List<Pedido>
    fun atualizarStatus(uuid: String, status: StatusPedido): Pedido?
}

/** Fila de pedidos do balcão ainda não confirmados pela cozinha. */
interface FilaSaida {
    fun adicionar(msg: JSONObject)
    fun todos(): List<JSONObject>
    fun remover(id: String)
}

/**
 * Servidor da cozinha. Protocolo: uma mensagem JSON por linha (UTF-8).
 *  balcão→cozinha: {"t":"novo",...pedido} | {"t":"status","id","status"} | {"t":"sync"} | {"t":"ping"}
 *  cozinha→balcão: {"t":"ack","id","numero"} | {"t":"pedido",...} | {"t":"pong"}
 */
class ServidorCozinha(
    private val store: PedidoStore,
    private val porta: Int,
    private val aoMudar: () -> Unit = {},
    private val aoNovo: (Pedido) -> Unit = {}
) {
    private var server: ServerSocket? = null
    private val conexoes = Collections.synchronizedList(mutableListOf<Conexao>())

    /** Abre a porta e devolve a porta real (útil quando se passa 0). */
    fun iniciar(): Int {
        val s = ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(porta))
        }
        server = s
        Thread({
            while (!s.isClosed) {
                try {
                    val c = Conexao(s.accept())
                    conexoes.add(c)
                    Thread({ c.rodar() }, "cozinha-conexao").start()
                } catch (e: IOException) {
                    break
                }
            }
        }, "cozinha-aceitar").start()
        return s.localPort
    }

    fun parar() {
        runCatching { server?.close() }
        synchronized(conexoes) { conexoes.toList() }.forEach { it.fechar() }
        conexoes.clear()
    }

    /** Muda o status de um pedido (ex.: finalizado na cozinha) e avisa todos os balcões. */
    fun mudarStatus(uuid: String, status: StatusPedido): Pedido? {
        val p = store.atualizarStatus(uuid, status) ?: return null
        difundir(PedidoJson.para(p).put("t", "pedido"))
        aoMudar()
        return p
    }

    private fun difundir(o: JSONObject) {
        synchronized(conexoes) { conexoes.toList() }.forEach { it.enviar(o) }
    }

    private inner class Conexao(val socket: Socket) {
        private val out = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))

        fun enviar(o: JSONObject): Boolean = synchronized(out) {
            try {
                out.write(o.toString()); out.write("\n"); out.flush(); true
            } catch (e: IOException) { false }
        }

        fun fechar() { runCatching { socket.close() } }

        fun rodar() {
            try {
                val inp = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
                while (true) {
                    val linha = inp.readLine() ?: break
                    tratar(linha)
                }
            } catch (_: IOException) {
            } finally {
                conexoes.remove(this)
                fechar()
            }
        }

        private fun tratar(linha: String) {
            try {
                val o = JSONObject(linha)
                when (o.optString("t")) {
                    "ping" -> enviar(JSONObject().put("t", "pong"))
                    "novo" -> {
                        val r = store.receber(PedidoJson.de(o))
                        enviar(JSONObject().put("t", "ack").put("id", r.pedido.uuid).put("numero", r.pedido.numero))
                        difundir(PedidoJson.para(r.pedido).put("t", "pedido"))
                        if (r.novo) aoNovo(r.pedido)
                        aoMudar()
                    }
                    "status" -> mudarStatus(o.getString("id"), StatusPedido.valueOf(o.getString("status")))
                    "sync" -> store.listar().forEach { enviar(PedidoJson.para(it).put("t", "pedido")) }
                }
            } catch (e: Exception) {
                enviar(JSONObject().put("t", "erro").put("msg", e.message ?: "erro"))
            }
        }
    }
}

/** Cliente do balcão: reconecta sozinho e reenvia o que a cozinha ainda não confirmou. */
class ClienteBalcao(
    private val fila: FilaSaida,
    private val hostProvider: () -> String?,
    private val porta: Int,
    private val intervaloReconexaoMs: Long = 3000
) {
    val conectado = MutableStateFlow(false)
    val pendentes = MutableStateFlow(fila.todos().size)
    val ultimoAck = MutableStateFlow<Int?>(null)
    val pedidos = MutableStateFlow<Map<String, Pedido>>(emptyMap())

    @Volatile private var rodando = false
    private var thread: Thread? = null
    private val sinal = Semaphore(0)

    fun iniciar() {
        if (rodando) return
        rodando = true
        thread = Thread({ ciclo() }, "balcao-rede").also { it.start() }
    }

    fun parar() {
        rodando = false
        thread?.interrupt()
        conectado.value = false
    }

    fun enviar(p: Pedido) {
        require(p.uuid.isNotBlank()) { "Pedido sem identificador" }
        fila.adicionar(PedidoJson.para(p).put("t", "novo"))
        pendentes.value = fila.todos().size
        sinal.release()
    }

    private fun ciclo() {
        while (rodando) {
            val host = hostProvider()
            if (host != null) {
                try { sessao(host) } catch (_: Exception) {}
            }
            conectado.value = false
            if (!dormir(intervaloReconexaoMs)) return
        }
    }

    private fun dormir(ms: Long): Boolean = try { Thread.sleep(ms); true } catch (e: InterruptedException) { false }

    private fun escrever(out: BufferedWriter, o: JSONObject) {
        out.write(o.toString()); out.write("\n"); out.flush()
    }

    private fun sessao(host: String) {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, porta), 3000)
            s.soTimeout = 15000
            val out = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
            val inp = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val vivo = AtomicBoolean(true)
            conectado.value = true
            escrever(out, JSONObject().put("t", "sync"))

            val leitor = Thread({
                try {
                    while (true) {
                        val linha = inp.readLine() ?: break
                        receber(linha)
                    }
                } catch (_: Exception) {
                } finally {
                    vivo.set(false)
                    sinal.release()
                }
            }, "balcao-leitor")
            leitor.start()

            val enviados = HashSet<String>()
            var ultimoPing = 0L
            try {
                while (rodando && vivo.get()) {
                    for (o in fila.todos()) {
                        if (enviados.add(o.getString("id"))) escrever(out, o)
                    }
                    val agora = System.currentTimeMillis()
                    if (agora - ultimoPing >= 5000) {
                        escrever(out, JSONObject().put("t", "ping"))
                        ultimoPing = agora
                    }
                    sinal.tryAcquire(1, TimeUnit.SECONDS)
                }
            } finally {
                runCatching { s.close() }
            }
        }
    }

    private fun receber(linha: String) {
        val o = try { JSONObject(linha) } catch (e: Exception) { return }
        when (o.optString("t")) {
            "ack" -> {
                fila.remover(o.getString("id"))
                pendentes.value = fila.todos().size
                ultimoAck.value = o.getInt("numero")
            }
            "pedido" -> runCatching {
                val p = PedidoJson.de(o)
                pedidos.value = pedidos.value + (p.uuid to p)
            }
        }
    }
}

class FilaMemoria : FilaSaida {
    private val itens = mutableListOf<JSONObject>()
    @Synchronized override fun adicionar(msg: JSONObject) {
        if (itens.none { it.getString("id") == msg.getString("id") }) itens.add(msg)
    }
    @Synchronized override fun todos(): List<JSONObject> = itens.toList()
    @Synchronized override fun remover(id: String) { itens.removeAll { it.getString("id") == id } }
}
