package br.com.delanhol.comandas.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import java.util.UUID
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/** Conexão BLE (GATT) com mini impressoras de gato: escreve em 0xAE01 e escuta 0xAE02. */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class GatoBle(private val ctx: Context) {
    private var gatt: BluetoothGatt? = null
    private var escrita: BluetoothGattCharacteristic? = null
    private var mtu = 23
    private val semPronto = Semaphore(0)
    private val semEscrita = Semaphore(0)
    @Volatile private var pausado = false
    @Volatile var pronto = false
        private set
    @Volatile private var falha: String? = null

    private fun uuid16(v: Int) = UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", v))
    private val svc = uuid16(0xAE30)
    private val charEscrita = uuid16(0xAE01)
    private val charAviso = uuid16(0xAE02)
    private val cccd = uuid16(0x2902)

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                if (!g.requestMtu(185)) g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                pronto = false
                if (falha == null) falha = "Impressora desconectou (código $status)"
                semPronto.release()
                semEscrita.release()
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, novoMtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = novoMtu
            g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val c = achaEscrita(g)
            if (status != BluetoothGatt.GATT_SUCCESS || c == null) {
                falha = "Não achei o canal de impressão desta mini impressora"
                semPronto.release()
                return
            }
            escrita = c
            val aviso = g.getService(svc)?.getCharacteristic(charAviso)
            val desc = aviso?.getDescriptor(cccd)
            if (aviso != null && desc != null) {
                g.setCharacteristicNotification(aviso, true)
                desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                if (!g.writeDescriptor(desc)) { pronto = true; semPronto.release() }
            } else {
                pronto = true
                semPronto.release()
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            pronto = true
            semPronto.release()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            semEscrita.release()
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            // A impressora avisa quando o buffer enche (XOff: 51 78 AE 01 01 00 10 ...) e quando esvazia.
            val d = c.value ?: return
            if (d.size >= 7 && d[0] == 0x51.toByte() && d[1] == 0x78.toByte() && d[2] == 0xAE.toByte()) {
                pausado = d[6] == 0x10.toByte()
            }
        }
    }

    private fun achaEscrita(g: BluetoothGatt): BluetoothGattCharacteristic? {
        g.getService(svc)?.getCharacteristic(charEscrita)?.let { return it }
        for (s in g.services) for (c in s.characteristics) {
            val p = c.properties
            if (c.uuid == charEscrita || (s.uuid != svc && p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0 &&
                    s.uuid.toString().startsWith("0000ae"))) return c
        }
        return null
    }

    /** Devolve null se deu certo, ou a mensagem de erro. */
    fun conectar(dev: BluetoothDevice): String? {
        fechar()
        falha = null; pronto = false; pausado = false; mtu = 23
        semPronto.drainPermits()
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        if (!semPronto.tryAcquire(15, TimeUnit.SECONDS)) {
            fechar()
            return "Tempo esgotado: a mini impressora não respondeu (ela está ligada e perto?)"
        }
        if (!pronto) {
            val m = falha ?: "Falha ao conectar"
            fechar()
            return m
        }
        return null
    }

    fun enviar(dados: ByteArray): String? {
        val g = gatt ?: return "Mini impressora desconectada"
        val c = escrita ?: return "Mini impressora desconectada"
        val semResposta = c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
        val tipo = if (semResposta) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                   else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        val tam = (mtu - 3).coerceIn(20, 180)
        var i = 0
        while (i < dados.size) {
            val limite = System.currentTimeMillis() + 4000
            while (pausado && System.currentTimeMillis() < limite) Thread.sleep(20)
            if (!pronto) return "Mini impressora desconectou durante a impressão"
            val n = minOf(tam, dados.size - i)
            val pedaco = dados.copyOfRange(i, i + n)
            semEscrita.drainPermits()
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, pedaco, tipo) == BluetoothStatusCodes.SUCCESS
            } else {
                c.writeType = tipo
                c.value = pedaco
                g.writeCharacteristic(c)
            }
            if (!ok) return "Falha ao enviar dados à mini impressora"
            semEscrita.tryAcquire(600, TimeUnit.MILLISECONDS)
            Thread.sleep(12)
            i += n
        }
        Thread.sleep(300)
        return null
    }

    fun fechar() {
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
        escrita = null
        pronto = false
    }

    companion object {
        /** Procura aparelhos BLE com nome por [ms] milissegundos. Os resultados chegam na thread principal. */
        fun buscar(
            ctx: Context,
            ms: Long,
            aoAchar: (DispositivoBt) -> Unit,
            aoFim: () -> Unit
        ): () -> Unit {
            val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter
            val scanner = ad?.bluetoothLeScanner
            if (scanner == null) { aoFim(); return {} }
            val handler = android.os.Handler(android.os.Looper.getMainLooper())
            var ativo = true
            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, r: ScanResult) {
                    val nome = r.scanRecord?.deviceName ?: r.device.name ?: return
                    aoAchar(DispositivoBt(nome, r.device.address))
                }
            }
            val parar = {
                if (ativo) {
                    ativo = false
                    runCatching { scanner.stopScan(callback) }
                    aoFim()
                }
            }
            runCatching { scanner.startScan(callback) }.onFailure { parar(); return {} }
            handler.postDelayed({ parar() }, ms)
            return { parar() }
        }
    }
}
