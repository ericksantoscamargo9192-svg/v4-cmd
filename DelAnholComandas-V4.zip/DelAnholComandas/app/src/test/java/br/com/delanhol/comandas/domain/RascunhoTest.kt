package br.com.delanhol.comandas.domain

import org.junit.Assert.*
import org.junit.Test

class RascunhoTest {
    @Test fun semPratoNaoEnvia() {
        assertNotNull(RascunhoPedido().erro())
    }
    @Test fun comPratoEnvia() {
        assertNull(RascunhoPedido(prato = "Frango").erro())
    }
    @Test fun adicionalSomaEZeraSemFicarNegativo() {
        var r = RascunhoPedido(tamanho = Tamanho.G)
        r = r.comAdicional(Adicional.OVO_FRITO, 1).comAdicional(Adicional.OVO_FRITO, 1)
        assertEquals(2500 + 400, r.totalCentavos)
        r = r.comAdicional(Adicional.OVO_FRITO, -5)
        assertEquals(2500, r.totalCentavos)
        assertTrue(r.adicionais.isEmpty())
    }
    @Test fun observacaoLongaInvalida() {
        assertNotNull(RascunhoPedido(prato = "x", observacao = "a".repeat(121)).erro())
    }
}
