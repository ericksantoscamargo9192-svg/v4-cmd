package br.com.delanhol.comandas.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Cores extraídas da logo do Restaurante e Lanchonete Del Anhol
val Marrom = Color(0xFF2A0A0A)
val Vermelho = Color(0xFFB3151B)
val Dourado = Color(0xFFF2B72B)
val Creme = Color(0xFFFFF4D6)

@Composable
fun DelAnholTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Vermelho, onPrimary = Creme,
            secondary = Dourado, onSecondary = Marrom,
            background = Creme, onBackground = Marrom,
            surface = Color.White, onSurface = Marrom
        ),
        content = content
    )
}
