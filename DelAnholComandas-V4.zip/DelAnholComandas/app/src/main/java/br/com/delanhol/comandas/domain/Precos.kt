package br.com.delanhol.comandas.domain

object Precos {
    /** Preço do PF e da marmita é o mesmo, conforme combinado. */
    fun total(tamanho: Tamanho, adicionais: Map<Adicional, Int>): Int {
        require(adicionais.values.all { it >= 0 }) { "Quantidade inválida" }
        return tamanho.precoCentavos +
            adicionais.entries.sumOf { (a, qtd) -> a.precoCentavos * qtd }
    }

    fun formatar(centavos: Int): String {
        val reais = centavos / 100
        val cts = centavos % 100
        return "R$ %d,%02d".format(reais, cts)
    }
}
