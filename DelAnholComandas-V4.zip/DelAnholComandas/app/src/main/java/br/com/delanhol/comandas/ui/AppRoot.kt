package br.com.delanhol.comandas.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.delanhol.comandas.R
import br.com.delanhol.comandas.data.*
import br.com.delanhol.comandas.ui.theme.Creme
import br.com.delanhol.comandas.ui.theme.Dourado
import br.com.delanhol.comandas.ui.theme.Marrom
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val config = remember { ConfigRepository(ctx) }
    val cardapioRepo = remember { CardapioRepository(ctx) }
    var modo by remember { mutableStateOf(config.modo()) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Cabecalho(mostrarTrocar = modo != null, onTrocar = { config.definirModo(null); modo = null })
        when (modo) {
            null -> EscolhaModo { m -> config.definirModo(m); modo = m }
            Modo.BALCAO -> BalcaoApp(cardapioRepo, config)
            Modo.COZINHA -> CozinhaApp()
        }
    }
}

@Composable
private fun Cabecalho(mostrarTrocar: Boolean, onTrocar: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Marrom).statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painterResource(R.drawable.logo_del_anhol), "Del Anhol",
            Modifier.height(52.dp).weight(1f), contentScale = ContentScale.Fit
        )
        if (mostrarTrocar) TextButton(onClick = onTrocar) { Text("Trocar modo", color = Dourado) }
    }
}

@Composable
private fun EscolhaModo(onEscolher: (Modo) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
    ) {
        Text("Este celular será:", fontFamily = FonteTitulo, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        BotaoModo("BALCÃO", "Cadastra os pedidos", Icons.Filled.PointOfSale) { onEscolher(Modo.BALCAO) }
        BotaoModo("COZINHA", "Recebe pedidos e imprime", Icons.Filled.Restaurant) { onEscolher(Modo.COZINHA) }
    }
}

@Composable
private fun BotaoModo(titulo: String, sub: String, icone: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(96.dp)) {
        Icon(icone, null, Modifier.size(36.dp))
        Spacer(Modifier.width(14.dp))
        Column {
            Text(titulo, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = Creme)
        }
    }
}

@Composable
private fun BalcaoApp(repo: CardapioRepository, config: ConfigRepository) {
    val ctx = LocalContext.current
    var aba by remember { mutableIntStateOf(0) }
    var pratos by remember { mutableStateOf(repo.carregar()) }
    var dialogoIp by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val busca = remember { BuscaCozinha(ctx) }
    val cliente = remember {
        ClienteBalcao(FilaPrefs(ctx), { config.ipCozinha() ?: busca.host }, Rede.PORTA)
    }
    DisposableEffect(Unit) {
        busca.iniciar(); cliente.iniciar()
        onDispose { cliente.parar(); busca.parar() }
    }
    val conectado by cliente.conectado.collectAsState()
    val pendentes by cliente.pendentes.collectAsState()
    val ack by cliente.ultimoAck.collectAsState()
    val pedidosRecebidos by cliente.pedidos.collectAsState()

    LaunchedEffect(ack) {
        ack?.let { snack.showSnackbar("Comanda nº $it recebida pela cozinha") }
    }

    Scaffold(
        topBar = { StatusConexao(conectado, pendentes) { dialogoIp = true } },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = aba == 0, onClick = { aba = 0 },
                    icon = { Icon(Icons.Filled.Restaurant, null) }, label = { Text("Pedido") }
                )
                NavigationBarItem(
                    selected = aba == 1, onClick = { aba = 1 },
                    icon = { Icon(Icons.Filled.RestaurantMenu, null) }, label = { Text("Cardápio") }
                )
                NavigationBarItem(
                    selected = aba == 2, onClick = { aba = 2 },
                    icon = { Icon(Icons.Filled.BarChart, null) }, label = { Text("Resumo") }
                )
            }
        }
    ) { pad ->
        if (aba == 0) {
            BalcaoScreen(
                pratos = pratos,
                onEnviar = { r -> cliente.enviar(r.paraPedido(UUID.randomUUID().toString())) },
                modifier = Modifier.padding(pad)
            )
        } else if (aba == 2) {
            ResumoTela(
                pedidos = pedidosRecebidos.values,
                onImprimir = null,
                modifier = Modifier.padding(pad)
            )
        } else {
            CardapioScreen(
                pratos = pratos,
                onSalvar = { repo.salvar(it); pratos = repo.carregar() },
                modifier = Modifier.padding(pad)
            )
        }
    }

    if (dialogoIp) {
        var texto by remember { mutableStateOf(config.ipCozinha() ?: "") }
        AlertDialog(
            onDismissRequest = { dialogoIp = false },
            title = { Text("Endereço da cozinha") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Deixe em branco para achar a cozinha automaticamente. Se não achar, digite o endereço mostrado na tela da cozinha.")
                    OutlinedTextField(
                        value = texto, onValueChange = { texto = it },
                        singleLine = true, label = { Text("IP da cozinha (ex.: 192.168.0.20)") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { config.definirIpCozinha(texto); dialogoIp = false }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { dialogoIp = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun StatusConexao(conectado: Boolean, pendentes: Int, onConfig: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color.White).padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(12.dp).clip(CircleShape)
                .background(if (conectado) Color(0xFF2E9E44) else Color(0xFFD32F2F))
        )
        Spacer(Modifier.width(8.dp))
        val txt = when {
            conectado && pendentes == 0 -> "Conectado à cozinha"
            conectado -> "Conectado — enviando $pendentes pedido(s)"
            pendentes > 0 -> "Sem conexão — $pendentes pedido(s) na fila"
            else -> "Procurando a cozinha…"
        }
        Text(txt, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
        IconButton(onClick = onConfig) { Icon(Icons.Filled.Settings, "Endereço da cozinha") }
    }
}
