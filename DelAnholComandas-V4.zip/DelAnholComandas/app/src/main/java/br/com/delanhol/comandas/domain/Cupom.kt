package br.com.delanhol.comandas.domain

import java.io.ByteArrayOutputStream
import java.text.Normalizer
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Caracteres por linha em papel térmico de 58 mm (fonte normal). */
const val LARGURA = 32

object Texto {
    /** Tabela PC860 (português) usada pela maioria das impressoras térmicas ESC/POS. */
    internal val CP860: Map<Char, Int> = mapOf(
        'Ç' to 0x80, 'ü' to 0x81, 'é' to 0x82, 'â' to 0x83, 'ã' to 0x84, 'à' to 0x85,
        'Á' to 0x86, 'ç' to 0x87, 'ê' to 0x88, 'Ê' to 0x89, 'Í' to 0x8B, 'Ô' to 0x8C,
        'Ã' to 0x8E, 'Â' to 0x8F, 'É' to 0x90, 'À' to 0x91, 'ô' to 0x93, 'õ' to 0x94,
        'Ú' to 0x96, 'Õ' to 0x99, 'Ü' to 0x9A, 'Ó' to 0x9F, 'á' to 0xA0, 'í' to 0xA1,
        'ó' to 0xA2, 'ú' to 0xA3, 'ª' to 0xA6, 'º' to 0xA7
    )

    fun semAcentos(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    /** Converte o texto para os bytes que a impressora entende. Desconhecidos viram '?'. */
    fun paraBytes(s: String, acentos: Boolean): ByteArray {
        val base = if (acentos) Normalizer.normalize(s, Normalizer.Form.NFC) else semAcentos(s)
        val out = ByteArrayOutputStream()
        for (c in base) {
            val b = when {
                c == '\n' -> 0x0A
                c.code in 32..126 -> c.code
                acentos && CP860.containsKey(c) -> CP860.getValue(c)
                else -> '?'.code
            }
            out.write(b)
        }
        return out.toByteArray()
    }

    /** Quebra o texto em linhas de no máximo [largura] caracteres, sem cortar palavras curtas. */
    fun quebrar(texto: String, largura: Int = LARGURA): List<String> {
        val linhas = mutableListOf<String>()
        for (paragrafo in texto.split("\n")) {
            var atual = ""
            for (palavra in paragrafo.split(" ").filter { it.isNotEmpty() }) {
                var p = palavra
                while (p.length > largura) {
                    if (atual.isNotEmpty()) { linhas.add(atual); atual = "" }
                    linhas.add(p.take(largura))
                    p = p.drop(largura)
                }
                atual = when {
                    atual.isEmpty() -> p
                    atual.length + 1 + p.length <= largura -> "$atual $p"
                    else -> { linhas.add(atual); p }
                }
            }
            linhas.add(atual)
        }
        return linhas
    }

    fun duasColunas(esq: String, dir: String, largura: Int = LARGURA): String {
        val e = if (esq.length + dir.length + 1 > largura) esq.take((largura - dir.length - 1).coerceAtLeast(0)) else esq
        val espaco = (largura - e.length - dir.length).coerceAtLeast(1)
        return e + " ".repeat(espaco) + dir
    }
}

/** Montador de comandos ESC/POS. */
class EscPos(private val acentos: Boolean) {
    private val buf = ByteArrayOutputStream()

    init {
        raw(0x1B, 0x40)                  // ESC @  : reinicia
        if (acentos) {
            raw(0x1C, 0x2E)              // FS .   : sai do modo chinês (senão bytes >127 viram ideogramas)
            raw(0x1B, 0x74, 3)           // ESC t 3: tabela PC860 (português)
        }
    }

    private fun raw(vararg b: Int) { b.forEach { buf.write(it) } }

    /** 0 = esquerda, 1 = centro, 2 = direita */
    fun alinhar(a: Int) = apply { raw(0x1B, 0x61, a) }
    fun negrito(ligado: Boolean) = apply { raw(0x1B, 0x45, if (ligado) 1 else 0) }
    /** 0x00 normal, 0x01 altura dupla, 0x11 altura e largura duplas */
    fun tamanho(n: Int) = apply { raw(0x1D, 0x21, n) }
    fun texto(s: String) = apply {
        val dados = Texto.paraBytes(s, acentos)
        buf.write(dados, 0, dados.size)
    }
    fun linha(s: String = "") = apply { texto(s); raw(0x0A) }
    fun separador() = linha("-".repeat(LARGURA))
    fun avancar(linhas: Int) = apply { raw(0x1B, 0x64, linhas) }
    fun montar(): ByteArray = buf.toByteArray()
}

object Cupons {
    private val HORA = DateTimeFormatter.ofPattern("HH:mm")
    private val DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    /** Comanda em bytes ESC/POS (impressora comum). */
    fun comanda(p: Pedido, acentos: Boolean, zona: ZoneId = ZoneId.systemDefault()): ByteArray =
        EscPosRender.render(comandaDoc(p, zona), acentos)

    fun comandaDoc(p: Pedido, zona: ZoneId = ZoneId.systemDefault()): Documento {
        val quando = Instant.ofEpochMilli(p.criadoEmMillis).atZone(zona)
        val d = DocBuilder()
        d.linha("RESTAURANTE DEL ANHOL", negrito = true, alin = 1)
        d.separador()
        d.linha("COMANDA ${p.numero}", negrito = true, tamanho = 2)
        d.linha(Texto.duasColunas("Hora: " + quando.format(HORA), quando.format(DATA)))
        d.linha("DESTINO:")
        d.linha(p.destino.rotulo.uppercase(), negrito = true, tamanho = 2)
        d.separador()
        d.linha("${p.tipo.rotulo.uppercase()} ${p.tamanho.rotulo}", negrito = true, tamanho = 1)
        Texto.quebrar(p.prato).forEach { d.linha(it, negrito = true) }
        p.adicionais.forEach { (a, q) ->
            Texto.quebrar("+ ${q}x ${a.rotulo}").forEach { d.linha(it) }
        }
        if (p.observacao.isNotBlank()) {
            d.separador()
            d.linha("OBSERVAÇÃO:", negrito = true)
            Texto.quebrar(p.observacao.trim()).forEach { d.linha(it, negrito = true) }
        }
        d.separador()
        d.linha(Texto.duasColunas("TOTAL", Precos.formatar(p.totalCentavos)), negrito = true)
        return d.montar()
    }

    fun resumoDoc(
        r: ResumoDia,
        agora: Long = System.currentTimeMillis(),
        zona: ZoneId = ZoneId.systemDefault()
    ): Documento {
        val d = DocBuilder()
        d.linha("RESTAURANTE DEL ANHOL", negrito = true, alin = 1)
        d.linha("FECHAMENTO DO DIA", negrito = true, alin = 1)
        d.linha(r.dia.format(DATA), alin = 1)
        d.separador()
        d.linha(Texto.duasColunas("TOTAL", Precos.formatar(r.totalCentavos)), negrito = true, tamanho = 1)
        d.linha(Texto.duasColunas("Comandas", r.comandas.toString()))
        d.linha(Texto.duasColunas("PF", r.pf.toString()))
        d.linha(Texto.duasColunas("Marmitas", r.marmitas.toString()))
        d.separador().linha("TAMANHOS", negrito = true)
        Tamanho.entries.forEach { d.linha(Texto.duasColunas(it.rotulo, (r.tamanhos[it] ?: 0).toString())) }
        d.separador().linha("ADICIONAIS", negrito = true)
        Adicional.entries.forEach { d.linha(Texto.duasColunas(it.rotulo, (r.adicionais[it] ?: 0).toString())) }
        d.separador().linha("VENDAS POR DESTINO", negrito = true)
        if (r.destinos.isEmpty()) d.linha("Sem vendas")
        r.destinos.forEach {
            d.linha(Texto.duasColunas("${it.rotulo} (${it.comandas})", Precos.formatar(it.totalCentavos)))
        }
        d.separador()
        d.linha("Impresso " + Instant.ofEpochMilli(agora).atZone(zona).format(HORA))
        return d.montar()
    }

    fun testeDoc(acentos: Boolean, mini: Boolean): Documento {
        val d = DocBuilder()
        d.linha("TESTE DE IMPRESSAO", negrito = true, alin = 1)
        d.linha("Restaurante Del Anhol").separador()
        d.linha("12345678901234567890123456789012")
        d.linha("Acentos: á é í ó ú ã õ ç Ç")
        d.linha(
            "Modo: " + when {
                mini -> "mini impressora (imagem)"
                acentos -> "com acentos (PC860)"
                else -> "sem acentos"
            }
        )
        d.separador().linha("Se leu tudo, esta OK", negrito = true)
        return d.montar()
    }
}
