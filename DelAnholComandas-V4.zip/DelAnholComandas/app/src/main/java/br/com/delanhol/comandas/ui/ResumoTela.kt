package br.com.delanhol.comandas.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.delanhol.comandas.domain.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val FORMATO_DIA = DateTimeFormatter.ofPattern("dd/MM/yyyy")

/** Resumo de vendas do dia. Com [onImprimir] nulo, só mostra (usado no balcão). */
@Composable
fun ResumoTela(
    pedidos: Collection<Pedido>,
    onImprimir: ((ResumoDia) -> Unit)?,
    modifier: Modifier = Modifier
) {
    var dia by remember { mutableStateOf(LocalDate.now()) }
    val r = Resumo.calcular(pedidos, dia)

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { dia = dia.minusDays(1) }) {
                Icon(Icons.Filled.ChevronLeft, contentDescription = "Dia anterior")
            }
            Text(
                (if (dia == LocalDate.now()) "Hoje · " else "") + dia.format(FORMATO_DIA),
                fontFamily = FonteTitulo, fontSize = 20.sp, fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { dia = dia.plusDays(1) }, enabled = dia.isBefore(LocalDate.now())) {
                Icon(Icons.Filled.ChevronRight, contentDescription = "Próximo dia")
            }
        }

        Secao("Total vendido") {
            Text(
                Precos.formatar(r.totalCentavos),
                fontFamily = FonteTitulo, fontSize = 34.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Linha("Comandas", r.comandas.toString())
            Linha("PF", r.pf.toString())
            Linha("Marmitas", r.marmitas.toString())
        }
        Secao("Tamanhos") {
            Tamanho.entries.forEach { Linha(it.rotulo, (r.tamanhos[it] ?: 0).toString()) }
        }
        Secao("Adicionais") {
            Adicional.entries.forEach { Linha(it.rotulo, (r.adicionais[it] ?: 0).toString()) }
        }
        Secao("Vendas por destino") {
            if (r.destinos.isEmpty()) Text("Sem vendas neste dia")
            r.destinos.forEach { Linha("${it.rotulo} (${it.comandas})", Precos.formatar(it.totalCentavos)) }
        }

        if (onImprimir != null) {
            Button(
                onClick = { onImprimir(r) },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Icon(Icons.Filled.Print, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("IMPRIMIR RESUMO", fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Linha(esq: String, dir: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(esq)
        Text(dir, fontWeight = FontWeight.Bold)
    }
}
