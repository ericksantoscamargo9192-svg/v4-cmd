package br.com.delanhol.comandas.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import br.com.delanhol.comandas.domain.Documento
import br.com.delanhol.comandas.domain.GatoProtocolo
import br.com.delanhol.comandas.domain.LARGURA
import br.com.delanhol.comandas.domain.Raster

/** Desenha o documento como imagem de 384 pontos de largura (para impressoras que só imprimem imagem). */
object RenderizadorDocumento {
    fun renderizar(doc: Documento): Raster {
        val larg = GatoProtocolo.LARGURA
        val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            color = Color.BLACK
        }
        // Ajusta o tamanho da letra para caber exatamente LARGURA (32) caracteres por linha.
        base.textSize = 20f
        val porLinha = base.measureText("0".repeat(LARGURA))
        val tamBase = 20f * larg / porLinha

        fun paintDe(tamanho: Int, negrito: Boolean) = Paint(base).apply {
            textSize = if (tamanho == 0) tamBase else tamBase * 2
            textScaleX = if (tamanho == 1) 0.5f else 1f
            isFakeBoldText = negrito
        }

        val alturas = doc.linhas.map { ln ->
            val fm = paintDe(ln.tamanho, ln.negrito).fontMetrics
            (fm.descent - fm.ascent + 4f)
        }
        val altura = (alturas.sum() + 24f).toInt()
        val bmp = Bitmap.createBitmap(larg, altura, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        var y = 0f
        doc.linhas.forEachIndexed { i, ln ->
            val p = paintDe(ln.tamanho, ln.negrito)
            val fm = p.fontMetrics
            val x = if (ln.alinhamento == 1) ((larg - p.measureText(ln.texto)) / 2f).coerceAtLeast(0f) else 0f
            canvas.drawText(ln.texto, x, y - fm.ascent + 2f, p)
            y += alturas[i]
        }

        val pixels = BooleanArray(larg * altura)
        val linha = IntArray(larg)
        for (yy in 0 until altura) {
            bmp.getPixels(linha, 0, larg, 0, yy, larg, 1)
            for (x in 0 until larg) {
                val c = linha[x]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                pixels[yy * larg + x] = lum < 150
            }
        }
        bmp.recycle()
        return Raster(altura, pixels)
    }
}
