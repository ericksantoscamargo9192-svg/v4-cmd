package br.com.delanhol.comandas.data

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

private const val TIPO_SERVICO = "_delanhol._tcp."

/** Endereço IPv4 deste celular na rede local (para mostrar na cozinha). */
fun ipLocal(): String? = runCatching {
    Collections.list(NetworkInterface.getNetworkInterfaces())
        .filter { it.isUp && !it.isLoopback }
        .flatMap { Collections.list(it.inetAddresses) }
        .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
        ?.hostAddress
}.getOrNull()

/** A cozinha se anuncia na rede para o balcão encontrá-la sem digitar IP. */
class AnuncioCozinha(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.RegistrationListener? = null

    fun iniciar(porta: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "DelAnholCozinha"
            serviceType = TIPO_SERVICO
            setPort(porta)
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(i: NsdServiceInfo, erro: Int) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, erro: Int) {}
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
        }
        listener = l
        runCatching { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) }
    }

    fun parar() {
        listener?.let { l -> runCatching { nsd.unregisterService(l) } }
        listener = null
    }
}

/** O balcão procura a cozinha. Se falhar, use o IP manual (engrenagem na tela). */
class BuscaCozinha(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    @Volatile var host: String? = null
        private set
    private var listener: NsdManager.DiscoveryListener? = null

    @Suppress("DEPRECATION")
    private val resolver = object : NsdManager.ResolveListener {
        override fun onResolveFailed(i: NsdServiceInfo, erro: Int) {}
        override fun onServiceResolved(i: NsdServiceInfo) {
            host = i.host?.hostAddress
        }
    }

    fun iniciar() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(tipo: String, erro: Int) {}
            override fun onStopDiscoveryFailed(tipo: String, erro: Int) {}
            override fun onDiscoveryStarted(tipo: String) {}
            override fun onDiscoveryStopped(tipo: String) {}
            @Suppress("DEPRECATION")
            override fun onServiceFound(i: NsdServiceInfo) {
                if (i.serviceType.contains("delanhol")) runCatching { nsd.resolveService(i, resolver) }
            }
            override fun onServiceLost(i: NsdServiceInfo) { host = null }
        }
        listener = l
        runCatching { nsd.discoverServices(TIPO_SERVICO, NsdManager.PROTOCOL_DNS_SD, l) }
    }

    fun parar() {
        listener?.let { l -> runCatching { nsd.stopServiceDiscovery(l) } }
        listener = null
    }
}
