package br.com.delanhol.comandas.domain

import org.junit.Assert.*
import org.junit.Test

class GatoTest {
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    @Test fun crcConfere() {
        assertEquals(0x9E, GatoProtocolo.crc8(byteArrayOf(0x32)))
    }

    @Test fun pacotesConferemComQuadrosPublicados() {
        assertEquals("5178a30001000000ff", hex(GatoProtocolo.pacote(0xA3, byteArrayOf(0))))
        assertEquals("5178a4000100329eff", hex(GatoProtocolo.pacote(0xA4, byteArrayOf(0x32))))
        assertEquals("5178bb0001000107ff", hex(GatoProtocolo.pacote(0xBB, byteArrayOf(1))))
    }

    @Test fun trabalhoTemInicioEFimDoProtocolo() {
        val h = hex(GatoProtocolo.trabalho(Raster(1, BooleanArray(GatoProtocolo.LARGURA)), 1))
        assertTrue(h.startsWith("5178a30001000000ff"))
        assertTrue(h.contains("5178a6000b00aa551738445f5f5f44382ca1ff"))
        assertTrue(h.contains("5178a6000b00aa5517000000000000001711ff"))
    }

    @Test fun primeiroPontoFicaNoBitMenosSignificativo() {
        val px = BooleanArray(GatoProtocolo.LARGURA)
        px[0] = true      // byte 0, bit 0
        px[9] = true      // byte 1, bit 1
        val l = GatoProtocolo.linha(Raster(1, px), 0)
        assertEquals(GatoProtocolo.BYTES_POR_LINHA, l.size)
        assertEquals(0x01, l[0].toInt())
        assertEquals(0x02, l[1].toInt())
    }

    @Test fun intensidadeMapeiaEnergia() {
        assertEquals(0x5DC0, GatoProtocolo.energia(1))
        assertTrue(GatoProtocolo.energia(0) < GatoProtocolo.energia(1))
        assertTrue(GatoProtocolo.energia(2) > GatoProtocolo.energia(1))
    }

    @Test fun comandaViraDocumentoComOsDados() {
        val p = Pedido(
            numero = 5, tipo = TipoPrato.PF, tamanho = Tamanho.M, prato = "Bife",
            adicionais = emptyMap(), destino = Destino.Entrega, observacao = "sem sal", uuid = "u"
        )
        val textos = Cupons.comandaDoc(p).linhas.map { it.texto }
        assertTrue(textos.contains("COMANDA 5"))
        assertTrue(textos.contains("ENTREGA"))
        assertTrue(textos.any { it.contains("sem sal") })
        assertTrue(textos.all { it.length <= LARGURA })
    }
}
