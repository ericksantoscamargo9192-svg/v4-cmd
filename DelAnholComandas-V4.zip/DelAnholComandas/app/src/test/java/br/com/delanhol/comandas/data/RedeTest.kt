package br.com.delanhol.comandas.data

import br.com.delanhol.comandas.domain.*
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicInteger

class MemoriaStore : PedidoStore {
    private val lista = mutableListOf<Pedido>()
    @Synchronized override fun receber(p: Pedido): Recebido {
        lista.firstOrNull { it.uuid == p.uuid }?.let { return Recebido(it, false) }
        val salvo = p.copy(numero = lista.size + 1)
        lista.add(salvo)
        return Recebido(salvo, true)
    }
    @Synchronized override fun listar(): List<Pedido> = lista.toList()
    @Synchronized override fun atualizarStatus(uuid: String, status: StatusPedido): Pedido? {
        val i = lista.indexOfFirst { it.uuid == uuid }
        if (i < 0) return null
        lista[i] = lista[i].copy(status = status)
        return lista[i]
    }
}

class RedeTest {
    private val servidores = mutableListOf<ServidorCozinha>()
    private val clientes = mutableListOf<ClienteBalcao>()

    @After fun limpar() {
        clientes.forEach { it.parar() }
        servidores.forEach { it.parar() }
    }

    private fun pedido(id: String) = Pedido(
        numero = 0, tipo = TipoPrato.MARMITA, tamanho = Tamanho.G, prato = "Frango",
        adicionais = mapOf(Adicional.OVO_FRITO to 2), destino = Destino.Mesa(3),
        observacao = "sem cebola\nlinha 2", uuid = id
    )

    private fun cliente(porta: Int): ClienteBalcao =
        ClienteBalcao(FilaMemoria(), { "127.0.0.1" }, porta, intervaloReconexaoMs = 200)
            .also { clientes.add(it) }

    private fun aguardar(ms: Long = 8000, cond: () -> Boolean) {
        val fim = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < fim) { if (cond()) return; Thread.sleep(50) }
        fail("Tempo esgotado")
    }

    @Test fun jsonIdaEVolta() {
        val p = pedido("u1").copy(numero = 7, status = StatusPedido.PRONTO)
        val volta = PedidoJson.de(JSONObject(PedidoJson.para(p).toString()))
        assertEquals(p.copy(criadoEmMillis = volta.criadoEmMillis), volta)
    }

    @Test fun storeEhIdempotente() {
        val s = MemoriaStore()
        assertEquals(1, s.receber(pedido("a")).pedido.numero)
        val repetido = s.receber(pedido("a"))
        assertEquals(1, repetido.pedido.numero)
        assertFalse(repetido.novo)
        assertEquals(2, s.receber(pedido("b")).pedido.numero)
    }

    @Test fun balcaoEnviaECozinhaNumera() {
        val store = MemoriaStore()
        val novos = AtomicInteger(0)
        val srv = ServidorCozinha(store, 0, aoNovo = { novos.incrementAndGet() }).also { servidores.add(it) }
        val c = cliente(srv.iniciar())
        c.iniciar()
        c.enviar(pedido("p1"))
        aguardar { c.ultimoAck.value == 1 }
        assertEquals(1, store.listar().size)
        assertEquals(0, c.pendentes.value)
        assertEquals(1, novos.get())
    }

    @Test fun pedidoFicaNaFilaAteACozinhaLigar() {
        val porta = ServerSocket(0).use { it.localPort }
        val c = cliente(porta)
        c.iniciar()
        c.enviar(pedido("p1"))
        Thread.sleep(600)
        assertEquals(1, c.pendentes.value)
        val store = MemoriaStore()
        servidores.add(ServidorCozinha(store, porta).also { it.iniciar() })
        aguardar { c.ultimoAck.value == 1 }
        assertEquals(0, c.pendentes.value)
        assertEquals(1, store.listar().size)
    }

    @Test fun segundoAparelhoRecebePedidoEStatusEmTempoReal() {
        val srv = ServidorCozinha(MemoriaStore(), 0).also { servidores.add(it) }
        val porta = srv.iniciar()
        val a = cliente(porta); val b = cliente(porta)
        a.iniciar(); b.iniciar()
        aguardar { a.conectado.value && b.conectado.value }
        a.enviar(pedido("p1"))
        aguardar { b.pedidos.value.containsKey("p1") }
        assertEquals("sem cebola\nlinha 2", b.pedidos.value.getValue("p1").observacao)
        srv.mudarStatus("p1", StatusPedido.PRONTO)
        aguardar { b.pedidos.value["p1"]?.status == StatusPedido.PRONTO }
    }
}
