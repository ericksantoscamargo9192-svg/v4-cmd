package br.com.delanhol.comandas.domain

/** Pedido em montagem no balcão. O número só é dado pela cozinha, ao receber. */
data class RascunhoPedido(
    val tipo: TipoPrato = TipoPrato.PF,
    val tamanho: Tamanho = Tamanho.M,
    val prato: String = "",
    val adicionais: Map<Adicional, Int> = emptyMap(),
    val destino: Destino = Destino.Mesa(1),
    val observacao: String = ""
) {
    val totalCentavos: Int get() = Precos.total(tamanho, adicionais)

    /** Devolve a mensagem de erro, ou null se o pedido pode ser enviado. */
    fun erro(): String? = when {
        prato.isBlank() -> "Escolha o prato do dia"
        observacao.length > MAX_OBS -> "Observação muito longa"
        else -> null
    }

    fun paraPedido(uuid: String) = Pedido(
        numero = 0, tipo = tipo, tamanho = tamanho, prato = prato, adicionais = adicionais,
        destino = destino, observacao = observacao.trim(), uuid = uuid
    )

    fun comAdicional(a: Adicional, delta: Int): RascunhoPedido {
        val novo = ((adicionais[a] ?: 0) + delta).coerceAtLeast(0)
        return copy(adicionais = if (novo == 0) adicionais - a else adicionais + (a to novo))
    }

    companion object { const val MAX_OBS = 120 }
}
