package br.com.delanhol.comandas.data

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import br.com.delanhol.comandas.domain.Documento
import br.com.delanhol.comandas.domain.EscPosRender
import br.com.delanhol.comandas.domain.GatoProtocolo
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.IOException
import java.util.UUID

enum class TipoImpressora { CLASSICA, GATO }

data class EstadoImpressora(
    val conectada: Boolean = false,
    val nome: String? = null,
    val ocupada: Boolean = false,
    val mensagem: String? = null,
    val tipo: TipoImpressora? = null
)

data class DispositivoBt(val nome: String, val endereco: String)

/**
 * Impressora da cozinha. Dois tipos:
 *  - CLASSICA: Bluetooth comum (SPP) com ESC/POS. Precisa estar pareada nas configurações do celular.
 *  - GATO: mini impressora BLE de imagem (ex.: SC03h), escolhida pela busca dentro do app.
 * A conexão fica aberta e é refeita sozinha se cair.
 */
@SuppressLint("MissingPermission")
object ImpressoraBt {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    val estado = MutableStateFlow(EstadoImpressora())
    /** uuids dos pedidos já impressos nesta sessão. */
    val impressos = MutableStateFlow<Set<String>>(emptySet())

    private var app: Context? = null
    private var socket: BluetoothSocket? = null
    private var gato: GatoBle? = null
    private val trava = Any()

    fun iniciar(context: Context) {
        if (app == null) app = context.applicationContext
    }

    private fun ctx(): Context = app ?: throw IllegalStateException("Impressora não iniciada")

    fun temPermissao(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx(), Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    /** Para procurar mini impressoras (Android 12+: "Dispositivos por perto"; antes: localização). */
    fun temPermissaoBusca(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN
                   else Manifest.permission.ACCESS_FINE_LOCATION
        return ContextCompat.checkSelfPermission(ctx(), perm) == PackageManager.PERMISSION_GRANTED
    }

    private fun adaptador() = (ctx().getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun gato(): GatoBle = gato ?: GatoBle(ctx()).also { gato = it }

    fun pareadas(): List<DispositivoBt> {
        if (!temPermissao()) return emptyList()
        val ad = adaptador() ?: return emptyList()
        return runCatching {
            ad.bondedDevices.map { DispositivoBt(it.name ?: it.address, it.address) }.sortedBy { it.nome }
        }.getOrDefault(emptyList())
    }

    /** Procura mini impressoras BLE. Devolve uma função que cancela a busca. */
    fun buscarGatos(ms: Long, aoAchar: (DispositivoBt) -> Unit, aoFim: () -> Unit): () -> Unit =
        GatoBle.buscar(ctx(), ms, aoAchar, aoFim)

    fun conectar(
        endereco: String,
        nome: String?,
        tipo: TipoImpressora = TipoImpressora.CLASSICA
    ): Boolean = synchronized(trava) {
        fecharTudo()
        estado.value = EstadoImpressora(nome = nome, ocupada = true, mensagem = "Conectando…")
        try {
            if (!temPermissao()) throw IOException("Permissão de Bluetooth negada")
            val ad = adaptador() ?: throw IOException("Bluetooth indisponível neste aparelho")
            if (!ad.isEnabled) throw IOException("Bluetooth desligado")
            val dev = ad.getRemoteDevice(endereco)
            if (tipo == TipoImpressora.GATO) {
                val erro = gato().conectar(dev)
                if (erro != null) throw IOException(erro)
            } else {
                socket = abrir(dev)
            }
            estado.value = EstadoImpressora(conectada = true, nome = nome ?: dev.name, tipo = tipo)
            true
        } catch (e: Exception) {
            val m = if (e.message?.contains("BLUETOOTH_SCAN") == true)
                "Falta a permissão \"Dispositivos por perto\". Permita e tente de novo."
            else e.message
            estado.value = EstadoImpressora(nome = nome, mensagem = "Falha ao conectar: $m")
            false
        }
    }

    /** Tenta três jeitos de abrir a conexão clássica: alguns modelos baratos só aceitam o último. */
    private fun abrir(dev: BluetoothDevice): BluetoothSocket {
        var ultimo: Exception? = null
        val formas = listOf<() -> BluetoothSocket>(
            { dev.createRfcommSocketToServiceRecord(SPP) },
            { dev.createInsecureRfcommSocketToServiceRecord(SPP) },
            {
                dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(dev, 1) as BluetoothSocket
            }
        )
        for (criar in formas) {
            try {
                val s = criar()
                try {
                    s.connect()
                    return s
                } catch (e: Exception) {
                    runCatching { s.close() }
                    throw e
                }
            } catch (e: Exception) {
                ultimo = e
            }
        }
        throw IOException(ultimo?.message ?: "Não foi possível abrir a conexão")
    }

    fun reconectarSalva(): Boolean {
        val cfg = ConfigRepository(ctx())
        val end = cfg.impressoraEndereco() ?: return false
        if (estado.value.conectada) return true
        return conectar(end, cfg.impressoraNome(), cfg.impressoraTipo())
    }

    fun desconectar() = synchronized(trava) {
        fecharTudo()
        estado.value = EstadoImpressora(nome = estado.value.nome)
    }

    private fun fecharTudo() {
        runCatching { socket?.close() }
        socket = null
        gato?.fechar()
    }

    private fun estaConectada(tipo: TipoImpressora): Boolean =
        if (tipo == TipoImpressora.GATO) gato?.pronto == true else socket?.isConnected == true

    /** Imprime o documento na impressora escolhida. Reconecta e tenta de novo uma vez se tiver caído. */
    fun imprimir(doc: Documento, acentos: Boolean, uuid: String? = null): Boolean = synchronized(trava) {
        val cfg = ConfigRepository(ctx())
        val tipo = cfg.impressoraTipo()
        val dados: ByteArray = try {
            if (tipo == TipoImpressora.GATO) {
                GatoProtocolo.trabalho(RenderizadorDocumento.renderizar(doc), cfg.intensidade())
            } else {
                EscPosRender.render(doc, acentos)
            }
        } catch (e: Exception) {
            estado.value = estado.value.copy(mensagem = "Erro ao preparar a impressão: ${e.message}")
            return@synchronized false
        }
        for (tentativa in 1..2) {
            try {
                if (!estaConectada(tipo)) {
                    val end = cfg.impressoraEndereco() ?: throw IOException("Nenhuma impressora escolhida")
                    if (!conectar(end, cfg.impressoraNome(), tipo)) {
                        throw IOException(estado.value.mensagem ?: "Sem conexão com a impressora")
                    }
                }
                if (tipo == TipoImpressora.GATO) {
                    val erro = gato().enviar(dados)
                    if (erro != null) throw IOException(erro)
                } else {
                    val saida = socket!!.outputStream
                    var i = 0
                    while (i < dados.size) {
                        val n = minOf(256, dados.size - i)
                        saida.write(dados, i, n)
                        saida.flush()
                        i += n
                        Thread.sleep(25)
                    }
                }
                if (uuid != null) impressos.value = impressos.value + uuid
                estado.value = estado.value.copy(mensagem = null)
                return@synchronized true
            } catch (e: Exception) {
                fecharTudo()
                estado.value = EstadoImpressora(nome = estado.value.nome, mensagem = "Falha ao imprimir: ${e.message}")
            }
        }
        false
    }
}
